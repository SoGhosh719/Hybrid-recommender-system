
listmovies=[]
listmovies=movies
return render_template('shopping.html', listmovies=listmovies)